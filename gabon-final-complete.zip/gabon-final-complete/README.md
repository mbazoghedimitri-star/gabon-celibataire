# 🔥 GABON-LOVE - Application de Rencontre Gratuite

Bienvenue sur **Gabon-Love**, l'application de rencontre 100% gratuite pour le Gabon 🇬🇦 et la Diaspora en France 🇫🇷.

## ✨ Fonctionnalités

- ✅ **Inscription Dual-Path** : Gabon (téléphone) et France (email)
- ✅ **25 Likes/Jour** : Limité pour maintenir la qualité
- ✅ **2 Matches/Jour Max** : Système de rareté amusant
- ✅ **Messages 100% Gratuit** : Messagerie illimitée
- ✅ **Sécurisé** : RLS policies + chiffrement

## 💾 Stack Tech

- **Frontend** : React 18 + Vite
- **Styling** : Tailwind CSS
- **Backend** : Supabase (PostgreSQL)
- **Auth** : Supabase Auth
- **Hosting** : Vercel

---

**Créé avec ❤️ pour le Gabon et la Diaspora**
